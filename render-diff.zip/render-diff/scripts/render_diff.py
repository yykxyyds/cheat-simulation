#!/usr/bin/env python3
"""截图对比：给定干净页 HTML 和扰动页 HTML，判断渲染效果是否一致。

用法:
    python render_diff.py <pure.html> <perturbed1.html> [perturbed2.html ...]
    python render_diff.py <pure.html> -d <directory>           # 对比目录下所有 .html
    python render_diff.py <pure.html> -d <dir> --threshold 0.5  # 自定义阈值
    python render_diff.py <pure.html> <pert.html> --json        # JSON 输出
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional, Tuple

try:
    import numpy as np
    from PIL import Image
    from scipy import ndimage
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False


MSGEDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
DEFAULT_WINDOW = "1280,900"
DEFAULT_THRESHOLD = 0.5  # 百分比，超过这个值视为"不一致"


@dataclass
class DiffResult:
    file: str
    pure_screenshot: str
    pert_screenshot: str
    diff_pixels: int
    total_pixels: int
    diff_percent: float
    connected_regions: int
    region_bounds: Optional[Tuple[int, int, int, int]]  # row_start, row_end, col_start, col_end
    passed: bool
    threshold: float


def to_file_url(path: Path) -> str:
    """Windows 路径转 file:// URL，空格转 %20"""
    return "file:///" + str(path.resolve()).replace("\\", "/").replace(" ", "%20")


def screenshot(url: str, output: Path, window_size: str = DEFAULT_WINDOW) -> Path:
    """用 Edge headless 截图，返回截图路径。"""
    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        MSGEDGE_PATH,
        "--headless",
        f"--screenshot={str(output)}",
        f"--window-size={window_size}",
        url,
    ]
    subprocess.run(cmd, capture_output=True, timeout=30, check=False)
    if not output.exists():
        raise RuntimeError(f"截图失败: {output}")
    return output


def compute_diff(pure_path: Path, pert_path: Path) -> Tuple[int, int, float, int, Optional[Tuple[int, int, int, int]]]:
    """逐像素对比两张 PNG。返回 (diff_pixels, total, percent, regions, bounds)。"""
    pure = np.array(Image.open(pure_path))
    pert = np.array(Image.open(pert_path))

    if pure.shape != pert.shape:
        raise ValueError(f"截图尺寸不一致: {pure.shape} vs {pert.shape}")

    diff_mask = np.any(pure != pert, axis=2)
    diff_pixels = diff_mask.sum()
    total = pure.shape[0] * pure.shape[1]
    percent = diff_pixels / total * 100

    # 连通区域
    labeled, num = ndimage.label(diff_mask)

    # 边界
    rows = np.any(diff_mask, axis=1)
    cols = np.any(diff_mask, axis=0)
    if rows.any():
        r_idx = np.where(rows)[0]
        c_idx = np.where(cols)[0]
        bounds = (int(r_idx[0]), int(r_idx[-1]), int(c_idx[0]), int(c_idx[-1]))
    else:
        bounds = None

    return diff_pixels, total, percent, num, bounds


def run_comparison(
    pure_html: Path,
    pert_html: Path,
    work_dir: Path,
    threshold: float,
    window_size: str = DEFAULT_WINDOW,
) -> DiffResult:
    """对比一对 HTML，返回 DiffResult。"""
    pure_shot = work_dir / "pure.png"
    pert_shot = work_dir / f"{pert_html.stem}.png"

    pure_url = to_file_url(pure_html)
    pert_url = to_file_url(pert_html)

    screenshot(pure_url, pure_shot, window_size)
    screenshot(pert_url, pert_shot, window_size)

    diff_px, total, pct, regions, bounds = compute_diff(pure_shot, pert_shot)

    return DiffResult(
        file=str(pert_html),
        pure_screenshot=str(pure_shot),
        pert_screenshot=str(pert_shot),
        diff_pixels=diff_px,
        total_pixels=total,
        diff_percent=round(pct, 4),
        connected_regions=regions,
        region_bounds=bounds,
        passed=pct <= threshold,
        threshold=threshold,
    )


def _ensure_utf8():
    """确保 stdout/stderr 用 UTF-8 输出（Windows GBK 终端兼容）。"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            try:
                stream.reconfigure(encoding='utf-8', errors='replace')
            except Exception:
                pass


def print_report(results: List[DiffResult]) -> None:
    """表格输出对比结果。"""
    _ensure_utf8()
    lines = []
    lines.append("=" * 80)
    lines.append(f"{'文件':<45} {'差异%':>8} {'区域数':>7} {'判定':>8}")
    lines.append("-" * 80)

    for r in results:
        name = Path(r.file).name
        if len(name) > 43:
            name = name[:40] + "..."
        verdict = "一致" if r.passed else "不同"
        lines.append(f"{name:<45} {r.diff_percent:>7.2f}% {r.connected_regions:>6}  {verdict:>6}")

    lines.append("-" * 80)
    total_pass = sum(1 for r in results if r.passed)
    total_fail = len(results) - total_pass
    lines.append(f"通过: {total_pass}  未通过: {total_fail}  阈值: {results[0].threshold}%")
    lines.append("=" * 80)

    # 详细区域
    for r in results:
        if not r.passed and r.region_bounds:
            r0, r1, c0, c1 = r.region_bounds
            name = Path(r.file).name
            lines.append(f"\n[{name}] 差异区域: 行{r0}-{r1} 列{c0}-{c1} ({c1-c0+1}x{r1-r0+1}px)")

    sys.stdout.reconfigure(encoding='utf-8') if hasattr(sys.stdout, 'reconfigure') else None
    print("\n".join(lines))


def print_json(results: List[DiffResult]) -> None:
    """JSON 格式输出（方便程序处理）。"""
    _ensure_utf8()
    print(json.dumps([asdict(r) for r in results], ensure_ascii=False, indent=2))


def collect_htmls(paths: List[str], directory: Optional[str]) -> List[Path]:
    """收集要对比的扰动 HTML 文件列表。"""
    result = []
    if directory:
        d = Path(directory)
        result.extend(sorted(d.glob("*.html")))
    result.extend(Path(p) for p in paths)
    return [p for p in result if p.suffix.lower() in (".html", ".htm")]


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="HTML 渲染截图对比工具")
    ap.add_argument("pure", help="干净参考页 HTML")
    ap.add_argument("perturbed", nargs="*", help="扰动页 HTML（可多个）")
    ap.add_argument("-d", "--directory", help="扰动页所在目录（对比目录下所有 .html）")
    ap.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD,
                    help=f"差异百分比阈值（默认 {DEFAULT_THRESHOLD}%%）")
    ap.add_argument("--window-size", default=DEFAULT_WINDOW,
                    help=f"浏览器窗口尺寸（默认 {DEFAULT_WINDOW}）")
    ap.add_argument("--json", action="store_true", help="以 JSON 格式输出")
    ap.add_argument("--keep", action="store_true", help="保留截图文件（默认放在临时目录，用完即删）")
    ap.add_argument("--output-dir", help="截图输出目录（与 --keep 一起用）")

    args = ap.parse_args(argv)

    if not HAS_DEPS:
        print("缺少依赖: pip install pillow numpy scipy", file=sys.stderr)
        return 1

    if not os.path.exists(MSGEDGE_PATH):
        print(f"Edge 未找到: {MSGEDGE_PATH}", file=sys.stderr)
        return 1

    pure_html = Path(args.pure).resolve()
    if not pure_html.exists():
        print(f"干净页不存在: {pure_html}", file=sys.stderr)
        return 1

    pert_list = collect_htmls(args.perturbed, args.directory)
    if not pert_list:
        print("未指定扰动页（参数或 -d 目录为空）", file=sys.stderr)
        return 1

    # 过滤掉纯页本身
    pert_list = [p for p in pert_list if p.resolve() != pure_html]

    # 工作目录
    if args.keep and args.output_dir:
        work_dir = Path(args.output_dir)
        work_dir.mkdir(parents=True, exist_ok=True)
    else:
        work_dir_obj = tempfile.TemporaryDirectory(prefix="render_diff_")
        work_dir = Path(work_dir_obj.name)

    try:
        _ensure_utf8()
        results = []
        for pert in pert_list:
            print(f"对比: {pert.name}", file=sys.stderr)
            try:
                r = run_comparison(pure_html, pert, work_dir, args.threshold, args.window_size)
                results.append(r)
            except Exception as exc:
                print(f"  失败: {exc}", file=sys.stderr)
                results.append(DiffResult(
                    file=str(pert), pure_screenshot="", pert_screenshot="",
                    diff_pixels=0, total_pixels=0, diff_percent=100.0,
                    connected_regions=0, region_bounds=None,
                    passed=False, threshold=args.threshold,
                ))

        if args.json:
            print_json(results)
        else:
            print_report(results)

        return 0
    finally:
        if not args.keep:
            try:
                import shutil
                shutil.rmtree(work_dir, ignore_errors=True)
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
