---
name: render-diff
description: Screenshot two HTML pages with Edge headless and compare them pixel-by-pixel to judge whether browser rendering is identical. Use when the user asks to compare HTML rendering effects, check if a perturbation changes visible output, or batch-verify perturbation experiments against a clean reference page.
---

# Render Diff

## Overview

Given a clean HTML page and one or more perturbed HTML pages, screenshot all of them via Edge headless mode (same window size), then compare pixel-by-pixel. Output a diff report: percentage of different pixels, number of connected regions, location of difference, and pass/fail verdict based on a configurable threshold.

## Prerequisites

```bash
pip install pillow numpy scipy
```

Edge must be installed at `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`.

## Quick Start

### Single comparison

```bash
python scripts/render_diff.py page_pure.html page_perturbation.html
```

### Batch comparison (all .html in a directory)

```bash
python scripts/render_diff.py page_pure.html -d perturbation_dir/
```

### With JSON output (for programmatic consumption)

```bash
python scripts/render_diff.py page_pure.html -d pert_dir/ --json
```

### Custom threshold

```bash
python scripts/render_diff.py page_pure.html -d pert_dir/ --threshold 0.1
```

## Parameters

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `pure` | 干净参考页 HTML 路径 | 必填 |
| `perturbed` | 扰动页 HTML（可多个） | 可选 |
| `-d / --directory` | 扰动页所在目录（对比其中所有 .html） | - |
| `--threshold` | 差异百分比阈值，超过即判定为"不同" | 0.5% |
| `--window-size` | 浏览器窗口尺寸 | 1280,900 |
| `--json` | JSON 格式输出 | - |
| `--keep` | 保留截图文件 | - |
| `--output-dir` | 截图输出目录（需配合 --keep） | - |

## Interpreting Results

### Threshold guide

| 差异 | 判断 |
|------|------|
| < 0.01% | 渲染完全一致（可能是字体抗锯齿噪声） |
| 0.01% ~ 0.5% | 基本一致，可能有微小换行偏移，建议人工确认 |
| 0.5% ~ 5% | 存在可见差异，需要检查具体区域 |
| > 5% | 明显不同，不适用于"不影响用户所见"的场景 |

### Key metrics

- **diff_percent**: 差异像素占比。同页面两次截图应为 0%，验证 headless 渲染确定性。
- **connected_regions**: 连通区域数。越少越集中（可能是局部渲染差异），越多越分散（可能是字体/布局整体变化）。
- **region_bounds**: 差异区域的行列范围，据此判断差异对应页面哪个组件。

## Workflow for Batch Verification

When the user asks to batch-verify perturbation experiments:

1. Locate the clean reference `page_pure.html` and the directory containing `page_perturbation*.html` files.
2. Run `python scripts/render_diff.py <pure.html> -d <dir>`.
3. Report pass/fail counts. For failures, note the specific experiments and diff percentages.
4. If a failure is borderline (0.1%~1%), suggest the user review the specific region manually.

## Script Location

The comparison script is at `scripts/render_diff.py`. It is self-contained with no dependencies beyond pillow, numpy, and scipy.
